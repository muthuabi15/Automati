<?php
  	 session_start();
$_SESSION["user"] = "";
	 session_abort();
	 header("Location:index.html");
?>
