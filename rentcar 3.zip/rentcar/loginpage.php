<?php
	require "database.php";
	session_start();
	$strUser = $_POST['username'];
	$strPass = $_POST['password'];
	if (strcmp($strUser, "admin@admin.com") == 0 && strcmp($strPass, "admin") == 0) {
		  $_SESSION["user"] = 'admin';
		header("Location:adminhomepage.html");
	} else {
		$query = mysqli_query( $con,"SELECT * FROM customerdetails where EMAILID  = '$strUser' and password = '$strPass'");
		if ($row = mysqli_fetch_array($query)) {
		    $_SESSION["user"] = $strUser;
			header("Location:userhomepage.html");
			
		} else {
			$query = mysqli_query($con,"SELECT * FROM driverdetails where EMAILID  = '$strUser' and password = '$strPass'");
			if ($row = mysqli_fetch_array($query)) {
				$_SESSION["user"] = $strUser;
				header("Location:driverhomepage.html");
			}
			else {
			    $_SESSION["error"] = "Invalid Username or Password";
			    header("Location:login.php?status=Invalid Username Or Password");
			}
		}
	}

?>
