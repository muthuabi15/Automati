

<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>Customer | Register Customer </title>
      <meta name="description" content="Free Bootstrap Theme by BootstrapMade.com">
      <meta name="keywords" content="free website templates, free bootstrap themes, free template, free bootstrap, free website template">
      <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:400,300|Raleway:300,400,900,700italic,700,300,600">
      <link rel="stylesheet" type="text/css" href="css/jquery.bxslider.css">
      <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
      <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
      <link rel="stylesheet" type="text/css" href="css/animate.css">
      <link rel="stylesheet" type="text/css" href="css/style.css">
	  <script type="text/javascript" src="js/jquery-1.7.min.js"></script>

	 <style>
		.error {
	color: #D8000C;
	

}
	</style>

	

   </head>
   <body>
      <div class="loader"></div>
      <div id="myDiv">
         <!--HEADER-->
         <div class="header1">
            <div class="bg-color1">
               <header id="main-header">
                  <nav class="navbar navbar-default navbar-fixed-top">
                     <div class="container">
                        <div class="navbar-header">
                           <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                           <span class="icon-bar"></span>
                           <span class="icon-bar"></span>
                           <span class="icon-bar"></span>
                           </button>
                              <a class="navbar-brand" href="#">SMART<span class="logo-dec">TAXI</span></a>
                        </div>
                        <div class="collapse navbar-collapse" id="myNavbar">
                           <ul class="nav navbar-nav navbar-right">
                            <li class="active"><a href="index.html">Home</a></li>
                           </ul>
                        </div>
                     </div>
                  </nav>
               </header>
            </div>
         </div>
         <!--/ HEADER-->
         <!---->
         <div class="container">
            <form action="cregister.php" class="form-horizontal"  method="post"  id="target" >
               <div class="row">
                  <!-- page header -->
                  <div class="col-lg-10">
                     <h1 class="page-header">Registration Forms</h1>
                  </div>
                  <!--end page header -->
               </div>
               <div class="row">
                  <div class="col-lg-10">
                     <!-- Form Elements -->
                     <div class="panel panel-default">
                        <div class="panel-heading">
                          User Information
							<?php if(!empty($_GET['status'])) { ?>
                                    <label>
		
                                        <span style="color:red" id="status"><?php echo $_GET['status']; ?> </span>
                                    </label>
									<?php } ?>
                        </div>
                        <div class="panel-body">
                           <div class="row">
                              <div class="form-group form-group has-warning">
                                 <label class="col-md-4 control-label">Name</label>  
                                 <div class="col-md-5 inputGroupContainer">
                                    <div class="input-group">
                                       <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                                       <input name="firstname" placeholder="Person Name" id="fname" class="form-control" type="text">
                                    </div>
                                 </div>
							 
                              </div>
							 </div>

							<div class="row">
                              <div class="form-group form-group has-warning">
                                 <label class="col-md-4 control-label">Email Id</label>  
                                 <div class="col-md-5 inputGroupContainer">
                                    <div class="input-group">
                                       <span class="input-group-addon"><i class="glyphicon glyphicon-envelope"></i></span>
                                       <input name="emailid" placeholder="Email Id" id="email" class="form-control" type="email">
									  
                                    </div>
									
                                 </div>
								
                              </div>
							 </div>

							<div class="row">
                              <div class="form-group form-group has-warning">
                                 <label class="col-md-4 control-label">Password</label>  
                                 <div class="col-md-5 inputGroupContainer">
                                    <div class="input-group">
                                       <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                                       <input name="password" id="password" placeholder="Password" class="form-control" type="password">
									  
                                    </div>
									
                                 </div>
								
                              </div>
							 </div>

							

<div class="row">
                              <div class="form-group form-group has-warning">
                                 <label class="col-md-4 control-label">Mobile No</label>  
                                 <div class="col-md-5 inputGroupContainer">
                                    <div class="input-group">
                                       <span class="input-group-addon"><i class="glyphicon glyphicon-phone"></i></span>
                                       <input name="mobile" placeholder="Mobile No" id="mobile" class="form-control" type="number_format">
                                    </div>
									
                                 </div>

                              </div>
							 </div>

<div class="row">
                              <div class="form-group form-group has-warning">
                                 <label class="col-md-4 control-label">Date of Birth</label>  
                                 <div class="col-md-5 inputGroupContainer">
                                    <div class="input-group">
                                       <span class="input-group-addon"><i class="glyphicon glyphicon-phone"></i></span>
                                       <input name="dob" placeholder="dob" id="dob" class="form-control" type="text">
                                    </div>
									
                                 </div>

                              </div>
							 </div>









<div class="row">
                              <div class="form-group form-group has-warning">
                                 <label class="col-md-4 control-label">Address</label>  
                                 <div class="col-md-5 inputGroupContainer">
                                    <div class="input-group">
 <span class="input-group-addon"><i class="glyphicon glyphicon-option-vertical"></i></span>

 <textarea name="address" id="address" placeholder="Address" class="form-control" type="text" ></textarea>
                                    </div>
								
                                 </div>

                              </div>
							 </div>
                              <div class="col-lg-5">
                                 <button  name="submit" type="submit" class="btn btn-success">Submit Button</button>
                              </div>
                          
                        </div>
                     </div>
                  </div>
               </div>
            </form>
         </div>
     
      
      <!---->
      <!---->
      <!---->
      <!---->
      <!---->
      <!---->
      <!---->
      <!---->
      <!---->
      <!---->
      <!---->
      <footer id="footer">
         <div class="container">
            <div class="row text-center">
               <p>&copy;  All Rights Reserved.</p>
               <div class="credits">
               </div>
            </div>
         </div>
      </footer>
      <!---->
      </div>
      <script src="js/jquery.min.js"></script>
      <script src="js/jquery.easing.min.js"></script>
      <script src="js/bootstrap.min.js"></script>
      <script src="js/wow.js"></script>
      <script src="js/jquery.bxslider.min.js"></script>
      <script src="js/custom.js"></script>
  
   </body>
</html>


