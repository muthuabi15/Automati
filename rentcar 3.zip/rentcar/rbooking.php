<?php
	session_start();
	require "database.php";

	$strPickup = $_POST['pickup'];
	$strDrop = $_POST['drop'];
	$strVehicle = $_POST['vehicle'];
	$strType = $_POST['type'];
	$strBookDate = $_POST['bookdate'];
	$strBooktime = $_POST['booktime'];


	$strEmail = $_SESSION["user"];
	$selectQuery = "select * from bookdetails where EMAILID = '$strEmail'";
	$result = mysqli_query($con,$selectQuery);
    if ($data = mysqli_fetch_array($result)) {
		echo "Welcome :".$_SESSION["user"];
		header("Location:booking.php?status=Already Registered");
	}
	else {
		if(empty($_SESSION["user"])) 
			$strType = 'user';
		$insertQuery = "INSERT INTO bookdetails VALUES  ('$strPickup', '$strDrop', '$strVehicle','$strType','$strBookDate','$strBooktime','$strEmail')";
		if($dbResult = mysqli_query($con,$insertQuery)) {
		
			$selectQuery = "select LICENSENO from driverdetails where LICENSENO not in (select LICENSENO from allocation where BOOKDATE = '$strBookDate')";
			$result = mysqli_query($con,$selectQuery);
		    if ($data = mysqli_fetch_array($result)) {
				$strLiceseNo =$data[0]; 
				$insertBooking = "insert into allocation values('$strEmail','$strLiceseNo','$strBookDate','$strBooktime','$strEmail')";
				if($dbResult = mysqli_query($con,$insertBooking)) {
				}
			}
			header("Location:booking.php?status=Saved");
		}
		else {
			header("Location:booking.php?status=".mysql_error());
		}
	}
?>
