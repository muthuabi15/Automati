<?php
	session_start();
	require "database.php";

	$strFirst = $_POST['firstname'];
	$strEmail = $_POST['emailid'];
	$strPass = $_POST['password'];
	$strMobile = $_POST['mobile'];
	$strDob = $_POST['dob'];
	$strAddress = $_POST['address'];



	$selectQuery = "select * from customerdetails where EMAILID = '$strEmail'";
	$result = mysqli_query($con,$selectQuery);
    if ($data = mysqli_fetch_array($result)) {
		echo "Welcome :".$_SESSION["user"];
		header("Location:customerregister.php?status=Already Registered");
	}
	else {
		if(empty($_SESSION["user"])) 
			$strType = 'user';
		$insertQuery = "INSERT INTO customerdetails VALUES  ('$strFirst','$strEmail','$strPass','$strMobile','$strDob','$strAddress')";
		if($dbResult = mysqli_query( $con,$insertQuery)) {
			header("Location:customerregister.php?status=Saved");
		}
		else {
			header("Location:customerregister.php?status=".mysql_error());
		}
	}
?>
