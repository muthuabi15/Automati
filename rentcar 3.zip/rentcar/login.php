<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login form</title>
    <link href="assets/plugins/bootstrap/bootstrap.css" rel="stylesheet" />
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/plugins/pace/pace-theme-big-counter.css" rel="stylesheet" />
	<link href="assets/css/style.css" rel="stylesheet" />
    <link href="assets/css/main-style.css" rel="stylesheet" />
    <script type="text/javascript" src="js/jquery-1.7.min.js"></script>
</head>
<body >
<form action="loginpage.php" method="post" autocomplete="off">
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-md-offset-4 text-center logo-margin ">
                </div>
            <div class="col-md-4 col-md-offset-4">
              <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Smart Car Login</h3>
                    </div>
                    <div class="panel-body">
                     
                            <fieldset>
                                   <div class="form-group">
                                    <input class="form-control" placeholder="Emailid" name="username" type="email" autofocus required>
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Password" name="password" type="password" value="" required>
                                </div>
                               
                                <!-- Change this to a button or input when using this as a form -->
                                <div class="form-group">
                                    <input class="btn btn-lg btn-success btn-block"  name="admin_login" type="submit" value="LogIn">
                               </div>

 <div class="checkbox">
                                    <label>
                                        <a href="customerregister.php">New User Signup</a>
                                    </label>
                               </div>
							 <div class="checkbox">
									<?php if(!empty($_GET['status'])) { ?>
                                    <label>
		
                                        <span style="color:red" id="status"><?php echo $_GET['status']; ?> </span>
                                    </label>
									<?php } ?>
                               </div>
                            </fieldset>
                        
                   </div>
                </div>
            </div>
        </div>
    </div>

     <!-- Core Scripts - Include with every page -->
    <script src="assets/plugins/jquery-1.10.2.js"></script>
    <script src="assets/plugins/bootstrap/bootstrap.min.js"></script>
    <script src="assets/plugins/metisMenu/jquery.metisMenu.js"></script>
</form>
</body>

</html>
