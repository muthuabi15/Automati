<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin | Reports</title>
    <meta name="description" content="Free Bootstrap Theme by BootstrapMade.com">
    <meta name="keywords" content="free website templates, free bootstrap themes, free template, free bootstrap, free website template">
    
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:400,300|Raleway:300,400,900,700italic,700,300,600">
    <link rel="stylesheet" type="text/css" href="css/jquery.bxslider.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/animate.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">

  </head>
  <body>

    <div class="loader"></div>
    <div id="myDiv">
    <!--HEADER-->
    <div class="header1">
      <div class="bg-color1">
        <header id="main-header">
        <nav class="navbar navbar-default navbar-fixed-top">
          <div class="container">
            <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
         <a class="navbar-brand" href="#">SMART<span class="logo-dec"> TAXI</span></a>
            </div>
            <div class="collapse navbar-collapse" id="myNavbar">
              <ul class="nav navbar-nav navbar-right">
                 <li class="active"><a href="adminhomepage.html">Home</a></li>
                <li class=""><a href="driverregister.php">Register Drivers</a></li>
                <li class=""><a href="driverreports.php">Driver Reports</a></li>
				<li class=""><a href="customersreports.php">Customer Reports</a></li>
				<li class=""><a href="bookreports.php">Book Reports</a></li>
                <li class=""><a href="logout.php">Logout</a></li>
              </ul>
            </div>
          </div>
        </nav>
        </header>
     
      </div>
    </div>
    <!--/ HEADER-->
    <!---->
    <section id="feature" class="section-padding wow fadeIn delay-05s">
      <div class="container">
        <div class="row">
             <div class="container">


<!-- Text input-->



    <table class="table table-bordered">
        <thead>
            <tr>
                <th>CUSTOMERNAME</th>
                <th>EMAILID</th>
				<th>PASSWORD</th>
				<th>MOBILENO</th>
				<th>DATEOFBIRTH</th>
				<th>ADDRESS</th>

            </tr>

        </thead>

        <tbody>

           <?php
				require "database.php";
                    $selectQuery = "select * from customerdetails";
                    $result = mysqli_query($con,$selectQuery);
                    while ($data = mysqli_fetch_array($result)) {
                        print("<tr>");
                        print("<td>" . $data[0] . "</td>");
                        print("<td>" . $data[1] . "</td>");
                        print("<td>" . $data[2] . "</td>");
                        print("<td>" . $data[3] . "</td>");
                        print("<td>" . $data[4] . "</td>");
					    print("<td>" . $data[5] . "</td>");
	                    print("</tr>");

                    }
                    ?>
          
        </tbody>

    </table>



<!-- Success message -->



</div>
        </div>
      </div>
    </section>
    
    <footer id="footer">
      <div class="container">
        <div class="row text-center">
          
          <div class="credits">
           
        </div>
        </div>
      </div>
    </footer>
    <!---->
  </div>
    <script src="js/jquery.min.js"></script>
    <script src="js/jquery.easing.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/wow.js"></script>
    <script src="js/jquery.bxslider.min.js"></script>
    <script src="js/custom.js"></script>
    <script src="contactform/contactform.js"></script>
    
  </body>
</html>
