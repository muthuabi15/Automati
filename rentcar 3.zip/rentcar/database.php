<?php
/**
 * Created by PhpStorm.
 * User: maghes
 * Date: 2/19/17
 * Time: 12:45 AM
 */

$host = '127.0.0.1';
$uname = 'root';
$pwd = '';
$db = 'taxibooking';

$con = mysqli_connect($host, $uname, $pwd,$db) or die('Connection Failed');
//mysql_select_db($db, $con) or die('Database Selection Failed');
?>
