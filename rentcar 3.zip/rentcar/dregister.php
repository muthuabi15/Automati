<?php
	session_start();
	require "database.php";

	$strFirst = $_POST['firstname'];
	$strLast = $_POST['lastname'];
	$strEmail = $_POST['emailid'];
	$strPass = $_POST['password'];
	$strCity = $_POST['city'];
	$strDob = $_POST['dob'];
	$strGender = $_POST['gender'];
	$strAddress = $_POST['address'];
	$strLicense = $_POST['license'];
    $strMobile=$_POST['mobile'];

	$selectQuery = "select * from driverdetails where EMAILID = '$strEmail'";
	$result = mysqli_query($con,$selectQuery);
    if ($data = mysqli_fetch_array($result)) {
		echo "Welcome :".$_SESSION["user"];
		header("Location:driverregister.php?status=Already Registered");
	}
	else {
		if(empty($_SESSION["user"])) 
			$strType = 'user';
		$insertQuery = "INSERT INTO driverdetails VALUES  ('$strFirst', '$strLast', '$strEmail','$strPass','$strCity','$strDob','$strGender','$strAddress','$strLicense','$strMobile')";
		if($dbResult = mysqli_query($con,$insertQuery)) {
			header("Location:driverregister.php?status=Saved");
		}
		else {
			header("Location:driverregister.php?status=".mysql_error());
		}
	}
?>
