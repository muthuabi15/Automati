$(document)
    .ready(
        function() {
         
            $('.error').hide();
            $('#mobile')
                .keydown(
                    function() {
                        if ((event.keyCode >= 48 && event.keyCode <= 57) || (event.keyCode == 8 || event.keyCode == 9 || event.keyCode == 46 || event.keyCode == 37 || event.keyCode == 39)) {

                            if ($('#mobile').val().length < 10 || event.keyCode == 8 || event.keyCode == 9 || event.keyCode == 46 || event.keyCode == 37 || event.keyCode == 39)
                                return;
                            else
                                event.preventDefault();
                        } else {
                            event.preventDefault();
                        }
                    });
            $('#age')
                .keydown(
                    function() {
                        if ((event.keyCode >= 48 && event.keyCode <= 57) || (event.keyCode == 8 || event.keyCode == 9 || event.keyCode == 46 || event.keyCode == 37 || event.keyCode == 39)) {

                            if ($('#age').val().length < 3 || event.keyCode == 8 || event.keyCode == 9 || event.keyCode == 46 || event.keyCode == 37 || event.keyCode == 39)
                                return;
                            else
                                event.preventDefault();
                        } else {
                            event.preventDefault();
                        }
                    });


            $('#ename')
                .keydown(
                    function() {
                        if ((event.keyCode >= 65 && event.keyCode <= 90) || ((event.keyCode >= 97 && event.keyCode <= 128)) || (event.keyCode == 8 || event.keyCode == 9 || event.keyCode == 46 || event.keyCode == 37 || event.keyCode == 39)) {
                            return;
                        } else {
                            event.preventDefault();
                        }
                    });
            $('#etype')
                .keydown(
                    function() {
                        if ((event.keyCode >= 65 && event.keyCode <= 90) || ((event.keyCode >= 97 && event.keyCode <= 128)) || (event.keyCode == 8 || event.keyCode == 9 || event.keyCode == 46 || event.keyCode == 37 || event.keyCode == 39)) {
                            return;
                        } else {
                            event.preventDefault();
                        }
                    });
            var result = $('#status').val();
            if (result != '') {
                $('#success').text(result);
                $('#success').show();
            }
            $("#target").submit(function(event) {
    
                var firstName = $('#ename').val();
                var lastName = $('#etype').val();
                var emaild = $('#date').val();
                var password = $('#desc').val();
               
                if (firstName == '') {
					 $('#ferror').show();
	                 event.preventDefault();
                } else {
                    $('#ferror').hide();
                }
                if (lastName == '') {
                    $('#lerror').show();
                    event.preventDefault();
                } else {
                    $('#lerror').hide();
                }
                if ( emaild  == '') {
                     $('#eemail').show();
                    event.preventDefault();
                } else {
                    $('#eemail').hide();
                }
                if (password.trim() == '') {

                    $('#epass').show();
                    event.preventDefault();
                } else {

                    $('#epass').hide();
                }
              
            });
           

        });

function validateEmail(sEmail) {
    var filter = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
    if (filter.test(sEmail)) {
        return false;
    } else {
        return true;
    }
}
