$(document)
    .ready(
        function() {
            $("#allergies").hide();
            $('.error').hide();
            $('#mobile')
                .keydown(
                    function() {
                        if ((event.keyCode >= 48 && event.keyCode <= 57) || (event.keyCode == 8 || event.keyCode == 9 || event.keyCode == 46 || event.keyCode == 37 || event.keyCode == 39)) {

                            if ($('#mobile').val().length < 10 || event.keyCode == 8 || event.keyCode == 9 || event.keyCode == 46 || event.keyCode == 37 || event.keyCode == 39)
                                return;
                            else
                                event.preventDefault();
                        } else {
                            event.preventDefault();
                        }
                    });
            $('#age')
                .keydown(
                    function() {
                        if ((event.keyCode >= 48 && event.keyCode <= 57) || (event.keyCode == 8 || event.keyCode == 9 || event.keyCode == 46 || event.keyCode == 37 || event.keyCode == 39)) {

                            if ($('#age').val().length < 3 || event.keyCode == 8 || event.keyCode == 9 || event.keyCode == 46 || event.keyCode == 37 || event.keyCode == 39)
                                return;
                            else
                                event.preventDefault();
                        } else {
                            event.preventDefault();
                        }
                    });


            $('#fname')
                .keydown(
                    function() {
                        if ((event.keyCode >= 65 && event.keyCode <= 90) || ((event.keyCode >= 97 && event.keyCode <= 128)) || (event.keyCode == 8 || event.keyCode == 9 || event.keyCode == 46 || event.keyCode == 37 || event.keyCode == 39)) {
                            return;
                        } else {
                            event.preventDefault();
                        }
                    });
            $('#lname')
                .keydown(
                    function() {
                        if ((event.keyCode >= 65 && event.keyCode <= 90) || ((event.keyCode >= 97 && event.keyCode <= 128)) || (event.keyCode == 8 || event.keyCode == 9 || event.keyCode == 46 || event.keyCode == 37 || event.keyCode == 39)) {
                            return;
                        } else {
                            event.preventDefault();
                        }
                    });
            var result = $('#status').val();
            if (result != '') {
                $('#success').text(result);
                $('#success').show();
            }
            $("#target").submit(function(event) {
                //$('.error').show();
			
                var firstName = $('#fname').val();
                var lastName = $('#lname').val();
                var emaild = $('#email').val();
                var password = $('#password').val();
                var retype = $('#retype').val();
                var mobile = $('#mobile').val();
              
                var address = $('#address').val();
				var city = $('#village').val();
                if (firstName == '') {
					 $('#ferror').show();
	                 event.preventDefault();
                } else {
                    $('#ferror').hide();
                }
                if (lastName == '') {
                    $('#lerror').show();
                    event.preventDefault();
                } else {
                    $('#lerror').hide();
                }
                if ( emaild  == '' || $.trim(emaild).length == 0 || validateEmail(emaild)) {
                     $('#eemail').show();
                    event.preventDefault();
                } else {
                    $('#eemail').hide();
                }
                if (password == '') {
                    $('#epass').show();
                    event.preventDefault();
                } else {
                    $('#epass').hide();
                }
                if (password != retype) {
                    $('#eretype').show();
                    event.preventDefault();
                } else {
                    $('#eretype').hide();
                }
               
                if (mobile == '') {
                    $('#emobile').show();
                    event.preventDefault();
                } else {
                    $('#emobile').hide();
                }
            
            });
           

        });

function validateEmail(sEmail) {
    var filter = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
    if (filter.test(sEmail)) {
        return false;
    } else {
        return true;
    }
}
