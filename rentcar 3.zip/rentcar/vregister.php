<?php
	session_start();
	require "database.php";

	$strName = $_POST['vehiclename'];
	$strMake = $_POST['make'];
	$strType = $_POST['type'];
	$strVehicle = $_POST['vehicle'];



	$selectQuery = "select * from vehicledetails where VEHICLENO = '$strVehicle'";
	$result = mysql_query($con,$selectQuery);
    if ($data = mysqli_fetch_array($result)) {
		echo "Welcome :".$_SESSION["user"];
		header("Location:vehicleregister.php?status=Already Registered");
	}
	else {
		if(empty($_SESSION["user"])) 
			$strType = 'user';
		$insertQuery = "INSERT INTO vehicledetails VALUES  ('$strName', '$strMake', '$strType','$strVehicle')";
		if($dbResult = mysqli_query($con,$insertQuery)) {
			header("Location:vehicleregister.php?status=Saved");
		}
		else {
			header("Location:vehicleregister.php?status=".mysql_error());
		}
	}
?>
